# BC Model Module

Implements the Behavior Cloning neural network for Clash Royale card placement prediction.

**Status:** Design complete, implementation pending.

## Architecture

CRFeatureExtractor (SB3-compatible) with full embedding approach:
- **Arena branch:** `nn.Embedding(156, 8)` for class IDs + 5 remaining channels -> 3-layer CNN -> 128 features
- **Vector branch:** `nn.Embedding(9, 8)` for card classes + 19 scalar features -> 2-layer MLP -> 64 features
- **Output:** Concatenated 192-dim feature vector

BCPolicy adds a 2-layer action head: `Linear(192, 256) + ReLU + Dropout + Linear(256, 2305)`

Total parameters: ~130K-200K

## Planned Files

| File | Description |
|------|-------------|
| `src/bc/feature_extractor.py` | CRFeatureExtractor - arena embedding + CNN, card embedding + MLP, 192-dim output |
| `src/bc/bc_policy.py` | BCPolicy - extractor + action head, save/load, predict_action with masking |
| `src/bc/bc_dataset.py` | BCDataset - loads .npz files, file-level 80/20 split, class weight computation |
| `src/bc/train_bc.py` | BCTrainer - custom PyTorch loop, weighted CE loss, cosine annealing, early stopping |
| `src/bc/CLAUDE.md` | Package technical reference (planned) |

## Training Approach

- Custom PyTorch training loop (NOT SB3 imitation library)
- Weighted cross-entropy: `noop_weight=0.3`, `action_weight=3.0`
- Cosine annealing LR starting at `3e-4`
- 80/20 file-level train/val split
- Early stopping with `patience=10`
- Gradient clipping at `1.0`

## PPO Transition

Feature extractor weights saved separately as `bc_feature_extractor.pt`. Load into MaskablePPO via `policy_kwargs`. Optionally freeze extractor during initial PPO training, then unfreeze with lower LR.

## Output Files

| File | Description |
|------|-------------|
| `best_bc.pt` | Full BC policy checkpoint |
| `bc_feature_extractor.pt` | Feature extractor weights only (for PPO) |
| `training_log.json` | Training metrics per epoch |

## Tests

~30 tests planned: 8 feature extractor, 7 policy, 9 dataset, 6 trainer

## Existing Documentation

- `docs/bc-analysis.md` - 964-line comprehensive analysis and decision guide
- `docs/plans/2026-02-22-bc-model-implementation.md` - Implementation plan

## Dependencies

torch, numpy, `src.encoder.encoder_constants`

## Depends On

- `dataset_builder_module` - produces the `.npz` files that BCDataset loads
